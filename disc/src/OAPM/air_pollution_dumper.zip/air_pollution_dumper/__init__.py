# -*- coding: utf-8 -*-

"""Top-level package for Open Air Pollution Monitor."""

__author__ = """Alexey Sergeevich Fyodorov"""
__email__ = 'Fyodorov.aleksej@gmail.com'
__version__ = '0.1.0'
